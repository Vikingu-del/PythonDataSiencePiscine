from .count_in_list import count_in_list

__all__ = ["count_in_list"]
# This means that __all__ exports whatever is being imported
# after saying from ft_package.count_in_list import *
