from setuptools import setup  # , find_packages


# with open("README.md", "r", encoding="utf-8") as f:
#     long_description = f.read()


# def get_version():
#     with open("ft_package/__init__.py", "r", encoding="utf-8") as f:
#         content = f.read()
#     return re.search(r"__version__ = ['\"]([^'\"]+)['\"]", content).group(1)

print("HELOO WORLDDDDDD")
setup(
    url="https://github.com/eseferi/ft_package",
)
